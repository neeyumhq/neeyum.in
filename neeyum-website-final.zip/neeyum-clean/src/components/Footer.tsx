"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Footer() {
    const pathname = usePathname();

    const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
        if (pathname === "/") {
            e.preventDefault();
            setTimeout(() => {
                const el = document.getElementById(id);
                if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
            }, 50);
        }
    };

    if (pathname === "/delete-account") {
        return null;
    }

    return (
        <footer id="site-footer">
            <div className="footer-grid">
                <div className="footer-brand">
                    <div className="logo">
                        Neeyum <span className="lab">LAB</span>
                    </div>
                <p>India's trading discipline ecosystem. Simulate crypto. Track real NSE/BSE trades. Ranked by behaviour — not profit.</p>
                </div>
                <div className="footer-col">
                    <h4>Products</h4>
                    <a href="https://app.neeyum.in" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--green)' }}>TradeOS — NSE/BSE ↗</a>
                    <Link href="/">Neeyum Lab — Crypto</Link>
                    <span style={{ color: 'var(--sub)', fontSize: '13px' }}>Neeyum Analyse — Soon</span>
                </div>
                <div className="footer-col">
                    <h4>Platform</h4>
                    <Link href="/#what" onClick={(e) => handleScrollTo(e, "what")}>What is Neeyum Lab</Link>
                    <Link href="/#pricing" onClick={(e) => handleScrollTo(e, "pricing")}>Explorer vs Discipline</Link>
                    <Link href="/#engine" onClick={(e) => handleScrollTo(e, "engine")}>5-Metric Framework</Link>
                    <Link href="/#levels" onClick={(e) => handleScrollTo(e, "levels")}>Level Structure</Link>
                    <Link href="/#leaderboard" onClick={(e) => handleScrollTo(e, "leaderboard")}>Leaderboard</Link>
                </div>
                <div className="footer-col">
                    <h4>Pricing</h4>
                    <Link href="/#pricing" onClick={(e) => handleScrollTo(e, "pricing")}>Explorer — Free</Link>
                    <Link href="/#pricing" onClick={(e) => handleScrollTo(e, "pricing")}>Discipline — $99/mo</Link>
                    <Link href="/#pricing" onClick={(e) => handleScrollTo(e, "pricing")}>Annual — $799/yr</Link>
                </div>
                <div className="footer-col">
                    <h4>Company</h4>
                    <Link href="/about">About</Link>
                    <Link href="/contact">Contact</Link>
                    <Link href="/privacy-policy">Privacy Policy</Link>
                    <Link href="/terms-of-use">Terms of Use</Link>
                    <Link href="/refund-policy">Refund Policy</Link>
                </div>
            </div>
            <div className="footer-bottom">
                <div className="footer-disclaimer">
                    <strong>⚠ Disclaimer:</strong> Neeyum Lab is a simulation-based platform. We do not execute trades, provide brokerage services, or offer financial advice. Crypto derivatives trading involves significant risk. All simulations use virtual capital only. © 2026 Neeyum Lab / Neeyum.in · All rights reserved.
                </div>
                <div className="footer-legal">
                    <Link href="/privacy-policy">Privacy</Link>
                    <Link href="/terms-of-use">Terms</Link>
                    <Link href="/refund-policy">Refunds</Link>
                    <Link href="/contact">Contact</Link>
                </div>
            </div>
        </footer>
    );
}
