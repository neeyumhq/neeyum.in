"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Navbar() {
    const [mobileNavOpen, setMobileNavOpen] = useState(false);
    const [navShadow, setNavShadow] = useState(false);
    const pathname = usePathname();

    const toggleMobile = () => setMobileNavOpen((prev) => !prev);
    const closeNav = () => setMobileNavOpen(false);

    useEffect(() => {
        const handleScroll = () => setNavShadow(window.scrollY > 10);
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
        if (pathname === "/") {
            e.preventDefault();
            closeNav();
            setTimeout(() => {
                const el = document.getElementById(id);
                if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
            }, 50);
        } else {
            closeNav();
        }
    };

    if (pathname === "/delete-account") return null;

    return (
        <>
            <nav id="navbar" style={{ boxShadow: navShadow ? "0 4px 48px rgba(0,0,0,0.5)" : "none" }}>
                {/* LOGO */}
                <div className="nav-logo">
                    <div style={{ paddingRight: "12px" }}>
                        Neeyum <span className="lab">LAB</span>
                    </div>
                    <a
                        href="https://play.google.com/store/apps/details?id=com.sleepyclassics.neeyum"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-nav-fill"
                        style={{ margin: 0 }}
                    >
                        Download App
                    </a>
                </div>

                {/* DESKTOP NAV — only 3 links */}
                <div className="nav-links">
                    <a
                        href="https://app.neeyum.in"
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ color: "var(--green)", fontWeight: 700, fontSize: "14px", textDecoration: "none" }}
                    >
                        TradeOS &#8599;
                    </a>
                    <Link
                        href="/#page-home"
                        onClick={(e) => handleScrollTo(e, "page-home")}
                    >
                        LAB
                    </Link>
                    <Link href="/scorecard">
                        Scorecard
                    </Link>
                </div>

                {/* HAMBURGER */}
                <button className="hamburger-btn" onClick={toggleMobile} aria-label="Menu">
                    <div className="hamburger" id="ham">
                        <div className="hline"></div>
                        <div className="hline"></div>
                        <div className="hline"></div>
                    </div>
                </button>
            </nav>

            {/* MOBILE NAV — same 3 links */}
            <div className={`mobile-nav ${mobileNavOpen ? "open" : ""}`} id="mobileNav">
                <a
                    href="https://app.neeyum.in"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: "var(--green)", fontWeight: 700, textDecoration: "none" }}
                    onClick={closeNav}
                >
                    TradeOS &#8599;
                </a>
                <Link href="/#page-home" onClick={(e) => handleScrollTo(e, "page-home")}>
                    LAB
                </Link>
                <Link href="/scorecard" onClick={closeNav}>
                    Scorecard
                </Link>
                <a
                    href="https://play.google.com/store/apps/details?id=com.sleepyclassics.neeyum"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary"
                    onClick={closeNav}
                >
                    Download App
                </a>
            </div>
        </>
    );
}
